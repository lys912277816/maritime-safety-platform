import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';

let html=await readFile('docs/index.html','utf8');
const js=html.match(/<script\b[^>]*src="\.\/([^"\s]+)"[^>]*><\/script>/);
const css=html.match(/<link\b[^>]*href="\.\/([^"\s]+\.css)"[^>]*>/);
if(!js||!css)throw new Error('Expected one bundled script and stylesheet');
const script=(await readFile('docs/'+js[1],'utf8')).replace(/<\/script/gi,'<\\/script');
const style=(await readFile('docs/'+css[1],'utf8')).replace(/<\/style/gi,'<\\/style');
html=html.replace(js[0],()=>`<script type="module">${script}</script>`).replace(css[0],()=>`<style>${style}</style>`);
if(/<(script|link)\b[^>]*(src|href)="\.\//.test(html))throw new Error('Unresolved local asset');
await mkdir('publish',{recursive:true});
await writeFile('publish/index.html',html);
await writeFile('publish/.nojekyll','');
await copyFile('README.md','publish/README.md');
console.log(`Self-contained GitHub Pages HTML: ${Buffer.byteLength(html)} bytes`);
