import {
  useEffect,
  useRef,
  useState,
  forwardRef,
  useImperativeHandle,
} from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";
import maplibregl, { Map as GLMap, GeoJSONSource } from "maplibre-gl";
import type { Snapshot, Position } from "../types";
import { splitDateline } from "../lib/geo.mjs";
import worldData from "../data/world.geojson?raw";

const worldGeometry = JSON.parse(worldData);

export type MapActions = {
  flyTo: (position: Position, zoom?: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  reset: () => void;
};
type Props = {
  data: Snapshot | null;
  layers: Record<string, boolean>;
  selectedId?: string;
  onSelect: (kind: string, id: string) => void;
  onReady?: () => void;
};
const collection = (features: any[] = []) =>
  ({ type: "FeatureCollection", features }) as any;
const point = (position: Position, properties: any) => ({
  type: "Feature",
  geometry: { type: "Point", coordinates: position },
  properties,
});
const line = (coordinates: Position[], properties: any, split = true) => ({
  type: "Feature",
  geometry: split
    ? { type: "MultiLineString", coordinates: splitDateline(coordinates) }
    : { type: "LineString", coordinates },
  properties,
});
const riskColor = [
  "step",
  ["get", "riskScore"],
  "#087f72",
  45,
  "#b76b10",
  65,
  "#cc4545",
] as any;
const resetMap = (m: GLMap, duration = 1200) =>
  m.fitBounds(
    [
      [-180, -56],
      [180, 76],
    ],
    {
      padding: { top: 38, bottom: 42, left: 22, right: 22 },
      maxZoom: 1.65,
      duration,
    },
  );

function circle(position: Position, radiusKm: number, properties: any) {
  const coords: Position[] = [];
  for (let a = 0; a <= 64; a++) {
    const angle = (a / 64) * Math.PI * 2;
    coords.push([
      position[0] +
        (Math.cos(angle) * radiusKm) /
          (111.32 * Math.cos((position[1] * Math.PI) / 180)),
      position[1] + (Math.sin(angle) * radiusKm) / 110.57,
    ]);
  }
  return {
    type: "Feature",
    geometry: { type: "Polygon", coordinates: [coords] },
    properties,
  };
}

const WorldMap = forwardRef<MapActions, Props>(function WorldMap(
  { data, layers, selectedId, onSelect, onReady },
  ref,
) {
  const container = useRef<HTMLDivElement>(null);
  const mapRef = useRef<GLMap>();
  const loaded = useRef(false);
  const dataRef = useRef(data);
  dataRef.current = data;
  const layersRef = useRef(layers);
  layersRef.current = layers;
  const selectRef = useRef(onSelect);
  selectRef.current = onSelect;
  const readyRef = useRef(onReady);
  readyRef.current = onReady;
  const markers = useRef(new Map<string, maplibregl.Marker>());
  const syncRef = useRef<() => void>(() => {});
  const labelLayoutRef = useRef<() => void>(() => {});
  const failRef = useRef<(message: string) => void>(() => {});
  const [mapError, setMapError] = useState("");

  labelLayoutRef.current = () => {
    const m = mapRef.current;
    const d = dataRef.current;
    const host = container.current;
    if (!m || !d || !host || !host.clientWidth || !host.clientHeight) return;
    type Rect = { left: number; top: number; right: number; bottom: number };
    const overlaps = (a: Rect, b: Rect) => a.left < b.right + 3 && a.right > b.left - 3 && a.top < b.bottom + 3 && a.bottom > b.top - 3;
    const hostRect = host.getBoundingClientRect();
    const occupied: Rect[] = [...(host.parentElement?.querySelectorAll<HTMLElement>(".map-context, .map-controls, .map-legend, .selection-card, .search-panel, .layers-panel") || [])]
      .filter(el => el.offsetWidth && el.offsetHeight)
      .map(el => { const r = el.getBoundingClientRect(); return { left: r.left - hostRect.left, top: r.top - hostRect.top, right: r.right - hostRect.left, bottom: r.bottom - hostRect.top }; });
    const candidates = d.regions.map(region => {
      const el = markers.current.get(region.id)?.getElement();
      if (!el) return null;
      const p = m.project(region.position);
      return { region, el, focused: document.activeElement === el, rect: { left: p.x - el.offsetWidth / 2, top: p.y + 15, right: p.x + el.offsetWidth / 2, bottom: p.y + 15 + el.offsetHeight } };
    }).filter((item): item is NonNullable<typeof item> => item !== null)
      .sort((a, b) => Number(b.focused) - Number(a.focused) || Number(b.region.id === selectedId) - Number(a.region.id === selectedId) || b.region.riskScore - a.region.riskScore);
    for (const { el, rect, focused } of candidates) {
      const inView = rect.left >= 4 && rect.right <= host.clientWidth - 4 && rect.top >= 4 && rect.bottom <= host.clientHeight - 4;
      const visible = layersRef.current.risk !== false && (focused || (inView && !occupied.some(box => overlaps(rect, box))));
      el.style.visibility = visible ? "visible" : "hidden";
      el.tabIndex = visible ? 0 : -1;
      el.setAttribute("aria-hidden", String(!visible));
      if (visible) occupied.push(rect);
    }
  };

  useImperativeHandle(ref, () => ({
    flyTo: (position, zoom = 4) =>
      mapRef.current?.flyTo({
        center: position,
        zoom,
        duration: 1200,
        essential: true,
      }),
    zoomIn: () => mapRef.current?.zoomIn(),
    zoomOut: () => mapRef.current?.zoomOut(),
    reset: () => {
      if (mapRef.current) resetMap(mapRef.current);
    },
  }));

  syncRef.current = () => {
    const m = mapRef.current;
    const d = dataRef.current;
    if (!m || !loaded.current || !d) return;
    const set = (name: string, features: any[]) =>
      (m.getSource(name) as GeoJSONSource)?.setData(collection(features));
    set(
      "routes",
      d.routes.map((r) =>
        line(r.coordinates, { id: r.id, name: r.name, riskScore: r.riskScore }),
      ),
    );
    set(
      "ships",
      d.ships
        .filter((s) => s.position?.every(Number.isFinite))
        .map((s) =>
          point(s.position, {
            id: s.id,
            name: s.name,
            course: s.course || 0,
            riskScore: s.riskScore,
            selected: s.id === selectedId,
          }),
        ),
    );
    set(
      "trails",
      d.ships
        .filter((s) => s.trail?.length > 1)
        .map((s) =>
          line(s.trail, {
            id: s.id,
            riskScore: s.riskScore,
            selected: s.id === selectedId,
          }),
        ),
    );
    set(
      "ports",
      d.ports.map((p) => point(p.position, { id: p.id, name: p.name })),
    );
    set(
      "regions",
      d.regions.map((r) =>
        circle(r.position, r.radiusKm || 280, {
          id: r.id,
          riskScore: r.riskScore,
          kind: r.kind,
        }),
      ),
    );
    set(
      "hotspots",
      d.regions.map((r) =>
        point(r.position, {
          id: r.id,
          name: r.name,
          riskScore: r.riskScore,
          newsCount: r.newsCount || 0,
        }),
      ),
    );
    const groups: Record<string, string[]> = {
      routes: ["route-glow", "route-lines"],
      ships: ["ship-trails", "ship-points"],
      ports: ["port-halo", "port-points"],
      risk: ["region-fill", "region-outline", "hotspot-ring", "hotspot-point"],
      news: ["news-halo"],
    };
    for (const [group, ids] of Object.entries(groups))
      for (const id of ids)
        if (m.getLayer(id))
          m.setLayoutProperty(
            id,
            "visibility",
            layersRef.current[group] === false ? "none" : "visible",
          );
    const currentIds = new Set(d.regions.map((r) => r.id));
    for (const [id, marker] of markers.current)
      if (!currentIds.has(id)) {
        marker.remove();
        markers.current.delete(id);
      }
    d.regions.forEach((r) => {
      let marker = markers.current.get(r.id);
      if (!marker) {
        const el = document.createElement("button");
        el.type = "button";
        el.onclick = (e) => {
          e.stopPropagation();
          selectRef.current("region", r.id);
        };
        el.onfocus = () => labelLayoutRef.current();
        marker = new maplibregl.Marker({
          element: el,
          anchor: "top",
          offset: [0, 15],
        })
          .setLngLat(r.position)
          .addTo(m);
        markers.current.set(r.id, marker);
      }
      const el = marker.getElement();
      el.classList.add("map-region-label");
      el.classList.toggle("high", r.riskScore >= 65);
      el.classList.toggle("medium", r.riskScore >= 45 && r.riskScore < 65);
      el.textContent = r.name;
      el.title = `${r.name} · 风险 ${r.riskScore}`;
      el.setAttribute(
        "aria-label",
        `${r.name}，规则风险指数 ${r.riskScore}，点击查看详情`,
      );
      el.setAttribute("aria-pressed", String(r.id === selectedId));
      el.style.display = layersRef.current.risk === false ? "none" : "";
      marker.setLngLat(r.position);
    });
    labelLayoutRef.current();
  };

  useEffect(() => {
    if (!container.current) return;
    let disposed = false;
    let failed = false;
    let startupTimer: ReturnType<typeof setTimeout> | undefined;
    setMapError("");
    const fail = (message: string) => {
      if (disposed || failed) return;
      failed = true;
      loaded.current = false;
      clearTimeout(startupTimer);
      setMapError(message);
      readyRef.current?.();
    };
    failRef.current = fail;
    let m: GLMap;
    try {
      m = new maplibregl.Map({
        container: container.current,
        center: [0, 18],
        zoom: 1.1,
        minZoom: -1,
        maxZoom: 11,
        attributionControl: false,
        renderWorldCopies: false,
        style: {
          version: 8,
          sources: { world: { type: "geojson", data: worldGeometry } },
          layers: [
            {
              id: "ocean",
              type: "background",
              paint: { "background-color": "#edf5f9" },
            },
            {
              id: "land",
              type: "fill",
              source: "world",
              paint: { "fill-color": "#fcfdfd", "fill-opacity": 1 },
            },
            {
              id: "coast",
              type: "line",
              source: "world",
              paint: { "line-color": "#b6c5cf", "line-width": 0.7 },
            },
          ],
        },
      });
    } catch {
      container.current.replaceChildren();
      fail(
        "当前浏览器无法启动地图渲染。请启用 WebGL 或硬件加速后重新加载，其他态势与分析功能仍可使用。",
      );
      return () => {
        disposed = true;
      };
    }
    mapRef.current = m;
    m.on("move", () => labelLayoutRef.current());
    m.on("resize", () => labelLayoutRef.current());
    startupTimer = setTimeout(
      () =>
        fail(
          "地图加载超时，请检查网络或服务连接后重新加载。其他态势与分析功能仍可使用。",
        ),
      45000,
    );
    m.on("error", () =>
      fail(
        "底图或航运图层加载失败，请检查服务连接后重新加载。其他态势与分析功能仍可使用。",
      ),
    );
    const contextLost = (event: Event) => {
      event.preventDefault();
      fail(
        "地图渲染连接已中断。请重新加载页面，必要时检查浏览器的硬件加速设置。",
      );
    };
    m.getCanvas().addEventListener("webglcontextlost", contextLost);
    m.on("load", () => {
      if (disposed || failed) return;
      clearTimeout(startupTimer);
      try {
        const grid: any[] = [];
        resetMap(m, 0);
        for (let lat = -60; lat <= 75; lat += 15)
          grid.push(
            line(
              [
                [-180, lat],
                [180, lat],
              ],
              {},
              false,
            ),
          );
        for (let lon = -180; lon <= 180; lon += 30)
          grid.push(
            line(
              [
                [lon, -80],
                [lon, 85],
              ],
              {},
            ),
          );
        m.addSource("grid", { type: "geojson", data: collection(grid) });
        m.addLayer({
          id: "grid-lines",
          type: "line",
          source: "grid",
          paint: {
            "line-color": "#91aab9",
            "line-width": 0.5,
            "line-opacity": 0.28,
            "line-dasharray": [2, 6],
          },
        });
        ["routes", "ships", "trails", "ports", "regions", "hotspots"].forEach(
          (name) => m.addSource(name, { type: "geojson", data: collection() }),
        );
        m.addLayer({
          id: "region-fill",
          type: "fill",
          source: "regions",
          paint: { "fill-color": riskColor, "fill-opacity": 0.08 },
        });
        m.addLayer({
          id: "region-outline",
          type: "line",
          source: "regions",
          paint: {
            "line-color": riskColor,
            "line-width": 1,
            "line-opacity": 0.5,
            "line-dasharray": [3, 3],
          },
        });
        m.addLayer({
          id: "route-glow",
          type: "line",
          source: "routes",
          paint: {
            "line-color": "#087f72",
            "line-width": 5,
            "line-opacity": 0.08,
          },
        });
        m.addLayer({
          id: "route-lines",
          type: "line",
          source: "routes",
          layout: { "line-join": "round", "line-cap": "round" },
          paint: {
            "line-color": riskColor,
            "line-width": 1.4,
            "line-opacity": 0.78,
          },
        });
        m.addLayer({
          id: "ship-trails",
          type: "line",
          source: "trails",
          paint: {
            "line-color": riskColor,
            "line-width": ["case", ["get", "selected"], 2, 0.65],
            "line-opacity": ["case", ["get", "selected"], 0.95, 0.32],
          },
        });
        m.addLayer({
          id: "news-halo",
          type: "circle",
          source: "hotspots",
          paint: {
            "circle-radius": [
              "interpolate",
              ["linear"],
              ["get", "newsCount"],
              0,
              0,
              1,
              20,
              30,
              32,
              100,
              48,
            ],
            "circle-color": "#c48421",
            "circle-blur": 0.85,
            "circle-opacity": 0.2,
          },
        });
        m.addLayer({
          id: "hotspot-ring",
          type: "circle",
          source: "hotspots",
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 1, 9, 5, 19],
            "circle-color": "transparent",
            "circle-stroke-color": riskColor,
            "circle-stroke-width": 1,
            "circle-stroke-opacity": 0.8,
          },
        });
        m.addLayer({
          id: "hotspot-point",
          type: "circle",
          source: "hotspots",
          paint: { "circle-radius": 3, "circle-color": riskColor },
        });
        m.addLayer({
          id: "port-halo",
          type: "circle",
          source: "ports",
          paint: {
            "circle-radius": 7,
            "circle-color": "#ffffff",
            "circle-opacity": 0.95,
          },
        });
        m.addLayer({
          id: "port-points",
          type: "circle",
          source: "ports",
          paint: {
            "circle-radius": ["interpolate", ["linear"], ["zoom"], 1, 2, 5, 4],
            "circle-color": "#245e87",
            "circle-stroke-color": "#ffffff",
            "circle-stroke-width": 1.3,
          },
        });
        const canvas = document.createElement("canvas");
        canvas.width = 28;
        canvas.height = 36;
        const ctx = canvas.getContext("2d")!;
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.moveTo(14, 2);
        ctx.lineTo(23, 30);
        ctx.lineTo(14, 25);
        ctx.lineTo(5, 30);
        ctx.closePath();
        ctx.fill();
        m.addImage("ship-arrow", ctx.getImageData(0, 0, 28, 36), { sdf: true });
        m.addLayer({
          id: "ship-points",
          type: "symbol",
          source: "ships",
          layout: {
            "icon-image": "ship-arrow",
            "icon-size": [
              "interpolate",
              ["linear"],
              ["zoom"],
              1,
              0.22,
              5,
              0.42,
              10,
              0.65,
            ],
            "icon-rotate": ["get", "course"],
            "icon-rotation-alignment": "map",
            "icon-allow-overlap": true,
          },
          paint: {
            "icon-color": riskColor,
            "icon-opacity": 0.95,
            "icon-halo-color": "#ffffff",
            "icon-halo-width": 0.75,
          },
        });
        if (failed) return;
        loaded.current = true;
        syncRef.current();
        readyRef.current?.();
        const interactiveLayers = [
          ["ship-points", "ship"],
          ["port-points", "port"],
          ["hotspot-point", "region"],
          ["route-lines", "route"],
        ];
        m.on("click", e => {
          const features = m.queryRenderedFeatures(e.point, { layers: interactiveLayers.map(([layer]) => layer) });
          for (const [layer, kind] of interactiveLayers) {
            const id = features.find(feature => feature.layer.id === layer)?.properties?.id;
            if (id) { selectRef.current(kind, String(id)); return; }
          }
        });
        for (const [layer] of interactiveLayers) {
          m.on("mouseenter", layer, () => {
            m.getCanvas().style.cursor = "pointer";
          });
          m.on("mouseleave", layer, () => {
            m.getCanvas().style.cursor = "";
          });
        }
      } catch {
        fail(
          "航运地图图层初始化失败，请重新加载页面。其他态势与分析功能仍可使用。",
        );
      }
    });
    const resize = new ResizeObserver(() => {
      if (!disposed && !failed) m.resize();
    });
    resize.observe(container.current);
    return () => {
      disposed = true;
      clearTimeout(startupTimer);
      resize.disconnect();
      loaded.current = false;
      m.getCanvas().removeEventListener("webglcontextlost", contextLost);
      markers.current.forEach((v) => v.remove());
      markers.current.clear();
      m.remove();
      mapRef.current = undefined;
    };
  }, []);
  useEffect(() => {
    try {
      syncRef.current();
    } catch {
      failRef.current(
        "航运图层更新失败，请重新加载页面。其他态势与分析功能仍可使用。",
      );
    }
  }, [data, layers, selectedId]);
  return (
    <>
      <div
        className="world-map"
        ref={container}
        aria-label="全球航道船舶风险交互地图"
      />
      {mapError && (
        <div
          className="map-loading"
          role="alert"
          style={{
            zIndex: 25,
            background: "#fffffff7",
            color: "#506576",
            padding: 30,
            textAlign: "center",
            gap: 13,
          }}
        >
          <AlertTriangle size={30} style={{ color: "#a66210" }} />
          <strong style={{ color: "#253c4b", fontSize: 15 }}>
            地图暂不可用
          </strong>
          <p style={{ maxWidth: 420, fontSize: 12, lineHeight: 1.8 }}>
            {mapError}
          </p>
          <button
            className="button secondary"
            onClick={() => window.location.reload()}
          >
            <RefreshCw size={14} />
            重新加载页面
          </button>
        </div>
      )}
    </>
  );
});

export default WorldMap;
