import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Compass,
  Download,
  ExternalLink,
  Globe2,
  KeyRound,
  LoaderCircle,
  Radio,
  RefreshCw,
  Search,
  ShieldAlert,
  ShieldCheck,
  Ship,
  SlidersHorizontal,
  Waves,
  X,
} from "lucide-react";

type RecordItem = Record<string, any>;
import { apiFetch } from "../lib/api";

function riskLabel(_level: string | undefined, score = 0) {
  if (score >= 65) return "高风险";
  if (score >= 45) return "需关注";
  return "较平稳";
}

function riskClass(score = 0) {
  return score >= 65 ? "critical" : score >= 45 ? "high" : "low";
}

function textOf(item: any): string {
  if (typeof item === "string") return item;
  return item?.text || item?.description || item?.name || item?.title || "";
}

function dateTime(value?: string | null) {
  if (!value) return "时间待更新";
  const date = new Date(value);
  return Number.isNaN(date.valueOf())
    ? "时间待更新"
    : date.toLocaleString("zh-CN", {
        timeZone: "Asia/Shanghai",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      });
}

function useDialog(onClose: () => void) {
  const closeRef = useRef(onClose);
  const previousFocus = useRef(document.activeElement as HTMLElement | null);
  closeRef.current = onClose;
  useEffect(() => {
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const dialogs = document.querySelectorAll<HTMLElement>('[role="dialog"]');
    const dialog = dialogs[dialogs.length - 1];
    dialog?.querySelector<HTMLElement>("button, input, select")?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeRef.current();
      if (event.key === "Tab") {
        const dialogs =
          document.querySelectorAll<HTMLElement>('[role="dialog"]');
        const dialog = dialogs[dialogs.length - 1];
        const controls = dialog?.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]), select:not([disabled]), a[href], [tabindex="0"]',
        );
        if (!controls?.length) return;
        const first = controls[0];
        const last = controls[controls.length - 1];
        if (!dialog.contains(document.activeElement)) {
          event.preventDefault();
          first.focus();
        } else if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = previousOverflow;
      if (previousFocus.current?.isConnected) previousFocus.current.focus();
    };
  }, []);
}

export function RiskPanel({
  regions = [],
  news = [],
  onSelectRegion,
  selectedRegionId,
}: {
  regions: RecordItem[];
  news: RecordItem[];
  onSelectRegion: (region: RecordItem) => void;
  selectedRegionId?: string | null;
}) {
  const [view, setView] = useState<"risk" | "news">("risk");
  const sorted = useMemo(
    () =>
      [...regions].sort((a, b) =>
        view === "news"
          ? (b.newsCount || 0) - (a.newsCount || 0)
          : (b.riskScore || 0) - (a.riskScore || 0),
      ),
    [regions, view],
  );
  const actualNewsCount = news.filter((item) => !item.isDemo).length;
  return (
    <section className="risk-panel" aria-label="重点区域风险监测">
      <div className="panel-heading">
        <div>
          <div className="eyebrow">REGIONAL INTELLIGENCE</div>
          <h2>重点区域监测</h2>
        </div>
        <span className="panel-count">
          {regions.length.toString().padStart(2, "0")}
        </span>
      </div>
      <div className="segmented-control" aria-label="区域排序">
        <button
          className={view === "risk" ? "active" : ""}
          onClick={() => setView("risk")}
        >
          <ShieldAlert size={14} />
          风险优先
        </button>
        <button
          className={view === "news" ? "active" : ""}
          onClick={() => setView("news")}
        >
          <Activity size={14} />
          {actualNewsCount ? "报道热度" : "示例热度"}
        </button>
      </div>
      <div className="risk-region-list">
        {sorted.map((region, index) => {
          const score = Number(region.riskScore || 0);
          const trend = Number(region.trend || 0);
          const regionNewsCount = news.filter(
            (item) => !item.isDemo && item.regionId === region.id,
          ).length;
          return (
            <button
              key={region.id}
              className={`risk-region-card ${riskClass(score)} ${selectedRegionId === region.id ? "selected" : ""}`}
              onClick={() => onSelectRegion(region)}
              aria-pressed={selectedRegionId === region.id}
            >
              <div className="risk-card-top">
                <span className="region-index">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <div className="region-name">
                  <strong>{region.name}</strong>
                  <span>
                    {region.enName ||
                      region.description ||
                      "全球航运重点关注区"}
                  </span>
                </div>
                <ChevronRight size={15} className="region-chevron" />
              </div>
              <div className="risk-card-score">
                <div>
                  <span className="risk-score-number">{Math.round(score)}</span>
                  <span className="risk-score-unit">/ 100</span>
                </div>
                <span className={`risk-level ${riskClass(score)}`}>
                  <i />
                  {riskLabel(region.level, score)}
                </span>
              </div>
              <div className="risk-meter">
                <span
                  style={{ width: `${Math.min(100, Math.max(0, score))}%` }}
                />
              </div>
              <div className="risk-factors">
                {(region.factors || [])
                  .slice(0, 2)
                  .map((factor: any, i: number) => (
                    <span key={i}>{textOf(factor)}</span>
                  ))}
              </div>
              <div className="risk-card-footer">
                <span>
                  <Activity size={12} />
                  {actualNewsCount
                    ? `${regionNewsCount} 篇关联报道`
                    : "示例关注事件"}
                </span>
                {trend !== 0 && actualNewsCount > 0 ? (
                  <span className={`risk-trend ${trend > 0 ? "up" : "down"}`}>
                    {trend > 0 ? (
                      <ArrowUpRight size={13} />
                    ) : (
                      <ArrowDownRight size={13} />
                    )}
                    {Math.abs(trend)}%
                  </span>
                ) : (
                  <span className="risk-trend">规则评分</span>
                )}
              </div>
            </button>
          );
        })}
        {!sorted.length && (
          <div className="panel-empty">
            <Globe2 size={26} />
            <p>正在加载区域态势</p>
          </div>
        )}
      </div>
      <div className="risk-panel-note">
        <span className="status-dot" />
        {actualNewsCount
          ? `${actualNewsCount} 篇在线报道已归集`
          : "示例事件 · 等待在线新闻接入"}
        <span title="区域分值为规则评估，不是官方风险分级">规则评估</span>
      </div>
    </section>
  );
}

export function NewsDrawer({
  news = [],
  regions = [],
  source,
  onClose,
  onSelectRegion,
}: {
  news: RecordItem[];
  regions: RecordItem[];
  source?: string;
  onClose: () => void;
  onSelectRegion: (region: RecordItem) => void;
}) {
  const [search, setSearch] = useState("");
  const [regionId, setRegionId] = useState("all");
  useDialog(onClose);
  const filtered = useMemo(
    () =>
      news
        .filter(
          (item) =>
            (regionId === "all" || item.regionId === regionId) &&
            `${item.title} ${item.source} ${regions.find((region) => region.id === item.regionId)?.name || ""}`
              .toLowerCase()
              .includes(search.toLowerCase()),
        )
        .sort(
          (a, b) =>
            new Date(b.publishedAt || 0).valueOf() -
            new Date(a.publishedAt || 0).valueOf(),
        ),
    [news, regions, search, regionId],
  );
  return (
    <div
      className="drawer-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <aside
        className="news-drawer"
        role="dialog"
        aria-modal="true"
        aria-labelledby="news-title"
      >
        <div className="modal-heading">
          <div>
            <div className="eyebrow">MARITIME NEWS INTELLIGENCE</div>
            <h2 id="news-title">航运情报动态</h2>
            <p>从公开报道发现热点，关联重点航道与区域。</p>
          </div>
          <button
            className="icon-button"
            aria-label="关闭新闻"
            onClick={onClose}
            autoFocus
          >
            <X size={20} />
          </button>
        </div>
        <div className="news-summary">
          <span>
            <strong>{news.filter((item) => !item.isDemo).length}</strong>{" "}
            在线报道
          </span>
          <span>
            <strong>
              {
                new Set(
                  news
                    .filter((item) => !item.isDemo && item.regionId)
                    .map((item) => item.regionId),
                ).size
              }
            </strong>{" "}
            关联区域
          </span>
          <span className="source-badge">{source || "公开新闻采样"}</span>
        </div>
        <div className="news-filters">
          <label className="search-input">
            <Search size={16} />
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="搜索新闻、地区或来源"
              aria-label="搜索新闻"
            />
          </label>
          <select
            aria-label="按地区筛选新闻"
            value={regionId}
            onChange={(event) => setRegionId(event.target.value)}
          >
            <option value="all">全部区域</option>
            {regions.map((region) => (
              <option key={region.id} value={region.id}>
                {region.name}
              </option>
            ))}
          </select>
        </div>
        <div className="news-article-list">
          {filtered.map((item, index) => {
            const region = regions.find(
              (candidate) => candidate.id === item.regionId,
            );
            return (
              <article
                className="news-article"
                key={item.id || `${item.title}-${index}`}
              >
                <div className="news-article-meta">
                  <span
                    className={`news-kind ${item.isDemo ? "demo" : "live"}`}
                  >
                    {item.isDemo ? "演示事件" : "在线报道"}
                  </span>
                  <time>{dateTime(item.publishedAt)}</time>
                </div>
                {item.url && !item.isDemo ? (
                  <a
                    className="news-article-title"
                    href={item.url}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {item.title}
                    <ExternalLink size={13} />
                  </a>
                ) : (
                  <h3>{item.title}</h3>
                )}
                {item.description && <p>{item.description}</p>}
                <div className="news-article-footer">
                  <span>
                    {item.source ||
                      (item.isDemo ? "平台演示数据" : "公开新闻源")}
                  </span>
                  {region && (
                    <button
                      onClick={() => {
                        onSelectRegion(region);
                        onClose();
                      }}
                    >
                      <Globe2 size={12} />
                      {region.name}
                      <ArrowRight size={12} />
                    </button>
                  )}
                </div>
              </article>
            );
          })}
          {!filtered.length && (
            <div className="panel-empty">
              <Search size={30} />
              <h3>暂无匹配报道</h3>
              <p>调整检索条件，或在数据接入中刷新新闻。</p>
            </div>
          )}
        </div>
        <div className="drawer-note">
          <AlertTriangle size={14} />
          <span>
            报道量用于衡量关注度。新闻匹配由关键词规则完成，不等同于事故发生量或官方警报。
          </span>
        </div>
      </aside>
    </div>
  );
}

export function AnalysisModal({
  ports = [],
  onClose,
}: {
  ports: RecordItem[];
  onClose: () => void;
}) {
  const [origin, setOrigin] = useState(
    () =>
      ports.find((port) => /上海|shanghai/i.test(`${port.name} ${port.id}`))
        ?.id ||
      ports[0]?.id ||
      "",
  );
  const [destination, setDestination] = useState(
    () =>
      ports.find((port) => /鹿特丹|rotterdam/i.test(`${port.name} ${port.id}`))
        ?.id ||
      ports[1]?.id ||
      "",
  );
  const [vesselType, setVesselType] = useState("container");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<RecordItem | null>(null);
  useDialog(onClose);
  const requestId = useRef(0);
  useEffect(
    () => () => {
      requestId.current += 1;
    },
    [],
  );
  const analyze = async () => {
    if (!origin || !destination) {
      setError("请选择出发港和目的港。");
      return;
    }
    if (origin === destination) {
      setError("出发港与目的港需要不同。");
      return;
    }
    const id = ++requestId.current;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const response = await apiFetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ origin, destination, vesselType }),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.error || data.message || "航线评估暂不可用");
      if (id === requestId.current) setResult(data);
    } catch (cause) {
      if (id === requestId.current)
        setError(
          cause instanceof Error ? cause.message : "请求失败，请稍后再试。",
        );
    } finally {
      if (id === requestId.current) setLoading(false);
    }
  };
  const exportReport = () => {
    if (!result) return;
    const originName = ports.find((port) => port.id === origin)?.name || origin;
    const destinationName =
      ports.find((port) => port.id === destination)?.name || destination;
    const alternatives = (result.alternatives || []).slice(0, 2);
    const contents = [
      `# 航线风险决策简报`,
      "",
      `航线：${originName} → ${destinationName}`,
      `生成时间：${dateTime(result.analyzedAt || new Date().toISOString())}`,
      "风险数据：情景基线 · 规则评估",
      `风险分值：${result.riskScore}/100`,
      "",
      "## 态势判断",
      "",
      result.summary || "",
      "",
      "## 备选航线对比",
      "",
      ...(alternatives.length
        ? alternatives.map(
            (item: RecordItem) =>
              `- ${item.name}：情景风险 ${item.riskScore}/100（${riskLabel(item.level, item.riskScore)}）；估算航程 ${Math.round(item.distanceNm).toLocaleString()} 海里；估算航时 ${item.etaHours} 小时（约 ${(item.etaHours / 24).toFixed(1)} 天）；相对主方案航程差 ${item.extraDistanceNm >= 0 ? "+" : ""}${Math.round(item.extraDistanceNm).toLocaleString()} 海里，航时差 ${item.extraHours >= 0 ? "+" : ""}${item.extraHours} 小时。`,
          )
        : ["当前参考航线网络未提供不同的备选方案。"]),
      "",
      "## 重点风险",
      "",
      ...(result.risks || []).map(
        (risk: RecordItem) =>
          `- ${risk.name}（${risk.riskScore}/100）：${(risk.factors || []).map(textOf).join("；")}`,
      ),
      "",
      "## 决策建议",
      "",
      ...(result.recommendations || []).map((item: any) => `- ${textOf(item)}`),
      "",
      "## 方法与限制",
      "",
      result.methodology ||
        "依据区域风险规则和可用数据生成，不是官方航行警告；实际航行应以海事主管机关、船长及公司安全管理体系要求为准。",
    ].join("\n");
    const url = URL.createObjectURL(
      new Blob([contents], { type: "text/markdown;charset=utf-8" }),
    );
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `航线风险简报_${new Date().toISOString().slice(0, 10)}.md`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="analysis-modal modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="analysis-title"
      >
        <div className="modal-heading">
          <div>
            <div className="eyebrow">ROUTE DECISION ASSISTANT</div>
            <h2 id="analysis-title">
              <Compass size={23} />
              航线决策分析
            </h2>
            <p>关联航道、区域事件和新闻，生成可解释的风险建议。</p>
          </div>
          <button
            className="icon-button"
            aria-label="关闭分析"
            onClick={onClose}
            autoFocus
          >
            <X size={20} />
          </button>
        </div>
        <div className="analysis-body">
          <form
            className="analysis-form"
            onSubmit={(event) => {
              event.preventDefault();
              void analyze();
            }}
          >
            <div className="form-section-label">
              <span>01</span> 航行任务
            </div>
            <label className="form-field">
              出发港
              <select
                value={origin}
                disabled={loading}
                onChange={(event) => {
                  setOrigin(event.target.value);
                  setResult(null);
                }}
              >
                {ports.map((port) => (
                  <option key={port.id} value={port.id}>
                    {port.name} · {port.country}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="button"
              className="swap-ports"
              disabled={loading}
              onClick={() => {
                setOrigin(destination);
                setDestination(origin);
                setResult(null);
              }}
              aria-label="交换起终点"
            >
              <ArrowDownRight size={15} />
              交换起终点
            </button>
            <label className="form-field">
              目的港
              <select
                value={destination}
                disabled={loading}
                onChange={(event) => {
                  setDestination(event.target.value);
                  setResult(null);
                }}
              >
                {ports.map((port) => (
                  <option key={port.id} value={port.id}>
                    {port.name} · {port.country}
                  </option>
                ))}
              </select>
            </label>
            <label className="form-field">
              船舶类型
              <select
                value={vesselType}
                disabled={loading}
                onChange={(event) => {
                  setVesselType(event.target.value);
                  setResult(null);
                }}
              >
                <option value="container">集装箱船</option>
                <option value="tanker">油轮 / 液货船</option>
                <option value="bulk">散货船</option>
              </select>
            </label>
            <div className="analysis-method">
              <ShieldCheck size={17} />
              <span>
                基于规则的辅助决策
                <br />
                <small>结果显示风险依据与数据模式</small>
              </span>
            </div>
            <button
              type="submit"
              className="primary-button"
              disabled={loading || !ports.length}
            >
              {loading ? (
                <LoaderCircle size={16} className="spin" />
              ) : (
                <Compass size={16} />
              )}
              {loading ? "正在分析航线…" : "生成决策简报"}
              {!loading && <ArrowRight size={15} />}
            </button>
            {error && (
              <div className="form-error" role="alert">
                <AlertTriangle size={15} />
                {error}
              </div>
            )}
          </form>
          <div className="analysis-result">
            {!result && !loading && (
              <div className="analysis-placeholder">
                <div className="analysis-orbit">
                  <Compass size={44} />
                  <span />
                  <span />
                </div>
                <h3>让每一次航行更有把握</h3>
                <p>选择起终港口，查看经过航道、重点风险与行动建议。</p>
                <div className="analysis-capabilities">
                  <span>
                    <Globe2 size={15} />
                    航道关联
                  </span>
                  <span>
                    <ShieldAlert size={15} />
                    风险解释
                  </span>
                  <span>
                    <Ship size={15} />
                    行动建议
                  </span>
                </div>
              </div>
            )}
            {loading && (
              <div className="analysis-placeholder">
                <LoaderCircle size={38} className="spin" />
                <h3>正在关联航道与区域风险</h3>
                <p>综合安全事件、气象、拥堵与航行风险规则。</p>
              </div>
            )}
            {result && (
              <div className="analysis-report">
                <div className="report-heading">
                  <span className="eyebrow">VOYAGE RISK BRIEF</span>
                  <button className="text-button" onClick={exportReport}>
                    <Download size={14} />
                    导出简报
                  </button>
                </div>
                <div className="report-score-row">
                  <div
                    className={`report-score ${riskClass(result.riskScore)}`}
                  >
                    {Math.round(result.riskScore || 0)}
                    <small>/100</small>
                  </div>
                  <div>
                    <span
                      className={`risk-level ${riskClass(result.riskScore)}`}
                    >
                      {riskLabel(result.level, result.riskScore)}
                    </span>
                    <p>
                      {typeof result.route === "string"
                        ? result.route
                        : result.route?.name || "航线综合评估"}
                    </p>
                  </div>
                </div>
                <div className="report-mode">
                  <span className="source-badge">情景基线 · 规则评估</span>
                  <span>{dateTime(result.analyzedAt)}</span>
                </div>
                <p className="report-summary">{result.summary}</p>
                {result.route?.distanceNm != null && (
                  <div className="route-estimates">
                    <span>
                      <Waves size={14} />
                      估算航程{" "}
                      <strong>
                        {Math.round(result.route.distanceNm).toLocaleString()}{" "}
                        nm
                      </strong>
                    </span>
                    {result.route.etaHours != null && (
                      <span>
                        <Clock3 size={14} />
                        估算航时{" "}
                        <strong>
                          {(result.route.etaHours / 24).toFixed(1)} 天
                        </strong>
                      </span>
                    )}
                  </div>
                )}
                {result.alternatives?.length > 0 && (
                  <>
                    <h3 className="report-subtitle">
                      <Compass size={16} />
                      备选航线对比
                    </h3>
                    <div className="report-risks">
                      {result.alternatives
                        .slice(0, 2)
                        .map((alternative: RecordItem, index: number) => (
                          <div
                            key={alternative.id || index}
                            className="report-risk"
                          >
                            <div>
                              <strong>{alternative.name}</strong>
                              <span
                                className={riskClass(alternative.riskScore)}
                              >
                                {Math.round(alternative.riskScore || 0)} / 100
                              </span>
                            </div>
                            <div className="route-estimates">
                              <span>
                                <Waves size={13} />
                                估算航程{" "}
                                <strong>
                                  {Math.round(
                                    alternative.distanceNm,
                                  ).toLocaleString()}{" "}
                                  nm
                                </strong>
                              </span>
                              <span>
                                <Clock3 size={13} />
                                估算航时{" "}
                                <strong>
                                  {(alternative.etaHours / 24).toFixed(1)} 天
                                </strong>
                              </span>
                            </div>
                            <p>
                              较主方案：航程{" "}
                              {alternative.extraDistanceNm >= 0 ? "+" : ""}
                              {Math.round(
                                alternative.extraDistanceNm,
                              ).toLocaleString()}{" "}
                              nm · 航时 {alternative.extraHours >= 0 ? "+" : ""}
                              {alternative.extraHours} 小时 ·{" "}
                              {riskLabel(
                                alternative.level,
                                alternative.riskScore,
                              )}
                            </p>
                          </div>
                        ))}
                    </div>
                  </>
                )}
                <h3 className="report-subtitle">
                  <ShieldAlert size={16} />
                  重点风险依据
                </h3>
                <div className="report-risks">
                  {(result.risks || []).map(
                    (risk: RecordItem, index: number) => (
                      <div key={risk.id || index} className="report-risk">
                        <div>
                          <strong>{risk.name}</strong>
                          <span className={riskClass(risk.riskScore)}>
                            {Math.round(risk.riskScore || 0)}
                          </span>
                        </div>
                        <p>
                          {(risk.factors || []).map(textOf).join(" · ") ||
                            "区域风险规则关联"}
                        </p>
                      </div>
                    ),
                  )}
                  {!result.risks?.length && (
                    <p className="muted">
                      当前航线未关联到已配置的重点风险区域。
                    </p>
                  )}
                </div>
                <h3 className="report-subtitle">
                  <CheckCircle2 size={16} />
                  建议行动
                </h3>
                <ol className="recommendation-list">
                  {(result.recommendations || []).map(
                    (item: any, index: number) => (
                      <li key={index}>{textOf(item)}</li>
                    ),
                  )}
                </ol>
                <p className="report-disclaimer">
                  {result.methodology ||
                    "辅助分析依据有限数据与风险规则生成。实际航行请结合最新航行通告、船长判断及公司安全管理要求。"}
                </p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

export function DataModal({
  status = {},
  onClose,
  onRefresh,
}: {
  /** Synchronize status after a mutation. This callback must only read data. */
  status: RecordItem;
  onClose: () => void;
  onRefresh: () => void | Promise<void>;
}) {
  const [connectionSettings, setConnectionSettings] = useState<RecordItem>({ canManage: false });
  useEffect(() => {
    let active = true;
    void apiFetch("/api/settings")
      .then(response => { if (!response.ok) throw new Error("配置状态读取失败"); return response.json(); })
      .then(data => { if (active) setConnectionSettings(data); })
      .catch(() => { if (active) setConnectionSettings({ canManage: false, storageError: "配置状态暂不可用，请稍后重新打开。" }); });
    return () => { active = false; };
  }, []);
  const canManage = connectionSettings.canManage === true;
  const [key, setKey] = useState("");
  const [saving, setSaving] = useState(false);
  const [modeBusy, setModeBusy] = useState<"demo" | "live" | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  useDialog(onClose);
  const ais = status.ais || {};
  const news = status.news || {};
  const stateLabels: Record<string, string> = {
    demo: "演示数据",
    live: "已连接",
    connecting: "连接中",
    loading: "获取中",
    error: "连接异常",
    stale: "数据延迟",
  };
  const connect = async (event: FormEvent) => {
    event.preventDefault();
    if (!canManage || saving || modeBusy) return;
    if (!key.trim()) {
      setError("请输入 AISStream API Key。");
      return;
    }
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const response = await apiFetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ aisApiKey: key.trim() }),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.error || data.message || "配置失败");
      setKey("");
      setConnectionSettings(data);
      setMessage(
        "密钥已在本机加密保存，重启后自动恢复。后端正在连接 AIS，结果以数据源状态为准。",
      );
      await onRefresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "接入失败，请重试。");
    } finally {
      setSaving(false);
    }
  };
  const switchMode = async (mode: "demo" | "live") => {
    if (!canManage || saving || modeBusy) return;
    setModeBusy(mode);
    setError("");
    setMessage("");
    try {
      const response = await apiFetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode }),
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(data.error || data.message || "模式切换失败");
      await onRefresh();
      setMessage(
        mode === "demo"
          ? "已切换为演示模式，在线 AIS 连接已停止。已配置的密钥保留，可随时恢复连接。"
          : "正在恢复 AIS 连接，收到有效船位后自动显示在线船舶。",
      );
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : "模式切换失败，请重试。",
      );
    } finally {
      setModeBusy(null);
    }
  };
  const refresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    setError("");
    setMessage("");
    try {
      const response = await apiFetch("/api/refresh", { method: "POST" });
      if (!response.ok) throw new Error("刷新请求失败，请稍后再试。");
      const data = await response.json();
      await onRefresh();
      if (
        ["error", "stale"].includes(data.status?.state) &&
        data.accepted !== false
      )
        setError(data.status.message || "新闻源暂不可用，已保留现有数据。");
      else
        setMessage(
          data.reason ||
            data.status?.message ||
            "已请求刷新，数据状态会随后台更新。",
        );
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "刷新失败。");
    } finally {
      setRefreshing(false);
    }
  };
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        className="data-modal modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="data-title"
      >
        <div className="modal-heading">
          <div>
            <div className="eyebrow">DATA CONNECTION CENTER</div>
            <h2 id="data-title">
              <SlidersHorizontal size={22} />
              数据接入与来源
            </h2>
            <p>查看数据状态，连接实时 AIS，了解每一项信息的边界。</p>
          </div>
          <button
            className="icon-button"
            aria-label="关闭数据接入"
            onClick={onClose}
            autoFocus
          >
            <X size={20} />
          </button>
        </div>
        <div className="data-modal-body">
          <div className="data-source-card">
            <div className="source-icon cyan">
              <Radio size={22} />
            </div>
            <div className="source-content">
              <div className="source-title">
                <h3>AIS 船舶位置与轨迹</h3>
                <span
                  className={`connection-badge ${ais.state === "live" ? "live" : "demo"}`}
                >
                  <i />
                  {stateLabels[ais.state] || "待连接"}
                </span>
              </div>
              <p>
                {ais.message ||
                  "未配置数据源时，船舶沿真实地理航道进行演示移动。"}
              </p>
              {ais.lastSuccessAt && (
                <small>上次有效数据：{dateTime(ais.lastSuccessAt)}</small>
              )}
              <div className="source-links">
                <a
                  href="https://aisstream.io/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  AISStream 获取密钥
                  <ExternalLink size={11} />
                </a>
                <span>服务器端 WebSocket</span>
              </div>
            </div>
          </div>
          <form
            className="ais-key-form"
            onSubmit={(event) => void connect(event)}
          >
            <label htmlFor="ais-key">
              <KeyRound size={14} />
              AISStream API Key
            </label>
            <div>
              <input
                id="ais-key"
                type="password"
                value={key}
                onChange={(event) => setKey(event.target.value)}
                placeholder={
                  ais.configured
                    ? "已配置 · 输入新密钥可替换"
                    : "粘贴密钥以接入在线 AIS"
                }
                autoComplete="off"
                spellCheck={false}
                disabled={!canManage || saving || modeBusy !== null}
              />
              <button
                className="primary-button"
                disabled={!canManage || saving || modeBusy !== null}
                type="submit"
              >
                {saving ? (
                  <LoaderCircle size={15} className="spin" />
                ) : (
                  <Radio size={15} />
                )}
                {saving ? "连接中" : "接入数据"}
              </button>
            </div>
            <small>
              {canManage
                ? connectionSettings.aisKeySaved
                  ? "密钥已在本机按 Windows 用户加密保存，重启后自动恢复，无需再次输入。"
                  : "接入后将按 Windows 用户加密保存，重启自动恢复；页面和报告不会返回密钥。"
                : "外网只读访问：密钥与数据模式请在运行平台的电脑上，通过本机地址管理。"}
              {connectionSettings.storageError && <span role="alert">{connectionSettings.storageError}</span>}
            </small>
            <div className="source-links">
              {ais.state !== "demo" ? (
                <button
                  className="text-button"
                  type="button"
                  disabled={!canManage || saving || modeBusy !== null}
                  onClick={() => void switchMode("demo")}
                >
                  {modeBusy === "demo" ? (
                    <LoaderCircle size={13} className="spin" />
                  ) : (
                    <Ship size={13} />
                  )}
                  切换为演示模式
                </button>
              ) : ais.configured ? (
                <button
                  className="text-button"
                  type="button"
                  disabled={!canManage || saving || modeBusy !== null}
                  onClick={() => void switchMode("live")}
                >
                  {modeBusy === "live" ? (
                    <LoaderCircle size={13} className="spin" />
                  ) : (
                    <Radio size={13} />
                  )}
                  恢复 AIS 连接
                </button>
              ) : null}
            </div>
          </form>
          <div className="data-source-card">
            <div className="source-icon amber">
              <Activity size={22} />
            </div>
            <div className="source-content">
              <div className="source-title">
                <h3>公开新闻与区域热度</h3>
                <span
                  className={`connection-badge ${news.state === "live" ? "live" : "demo"}`}
                >
                  <i />
                  {stateLabels[news.state] || "待更新"}
                </span>
              </div>
              <p>
                {news.message ||
                  "通过公开新闻源获取近24小时航运报道，以地区关键词聚合；新闻源不可用时显示明确标注的演示事件。"}
              </p>
              <small>
                优先查询 GDELT；不可用时尝试 gCaptain 官方 RSS 备用源。
              </small>
              {news.lastSuccessAt && (
                <small>上次成功更新：{dateTime(news.lastSuccessAt)}</small>
              )}
              <div className="source-links">
                <a
                  href="https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  GDELT DOC API
                  <ExternalLink size={11} />
                </a>
                <a
                  href="https://gcaptain.com/feed/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  gCaptain RSS 备用
                  <ExternalLink size={11} />
                </a>
                <button
                  type="button"
                  className="text-button"
                  onClick={() => void refresh()}
                  disabled={!canManage || refreshing}
                >
                  <RefreshCw size={12} className={refreshing ? "spin" : ""} />
                  {!canManage ? "后台每10分钟自动更新" : refreshing ? "正在刷新" : "刷新新闻"}
                </button>
              </div>
            </div>
          </div>
          <div className="data-source-card">
            <div className="source-icon muted">
              <Globe2 size={22} />
            </div>
            <div className="source-content">
              <div className="source-title">
                <h3>全球地理与风险底图</h3>
                <span className="source-badge">参考图层</span>
              </div>
              <p>
                主要港口与航道为地理参考。关注区表示历史安全事件与航运瓶颈；分值由规则生成，不能作为官方事故统计或航行预警。
              </p>
              <div className="source-links">
                <a
                  href="https://www.naturalearthdata.com/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Natural Earth 地理数据
                  <ExternalLink size={11} />
                </a>
                <a
                  href="https://www.imo.org/en/OurWork/Security/Pages/PiracyArmedRobberydefault.aspx"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  IMO 海事安全参考
                  <ExternalLink size={11} />
                </a>
              </div>
            </div>
          </div>
          {message && (
            <div className="form-success" role="status">
              <CheckCircle2 size={16} />
              {message}
            </div>
          )}
          {error && (
            <div className="form-error" role="alert">
              <AlertTriangle size={16} />
              {error}
            </div>
          )}
          <div className="data-disclaimer">
            <ShieldCheck size={16} />
            <p>
              平台区分演示轨迹、在线 AIS、新闻报道和规则判断。全球 AIS
              覆盖取决于数据供应商、授权及接收站覆盖，在线连接不代表全部船舶可见。
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
