export const API_ORIGIN = import.meta.env.VITE_API_ORIGIN ||
  "https://maritime-safety-review-20261108.jqy1316281374.chatgpt.site";

export const apiFetch = (endpoint: string, options?: RequestInit) =>
  fetch(`${API_ORIGIN.replace(/\/$/, "")}${endpoint}`, options);

export const webSocketUrl = () =>
  `${API_ORIGIN.replace(/^http/, "ws").replace(/\/$/, "")}/ws`;
