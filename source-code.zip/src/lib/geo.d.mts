export function splitDateline(
  coordinates: [number, number][],
): [number, number][][];
