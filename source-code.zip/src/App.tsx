import { useEffect, useRef, useState, useMemo } from "react";
import {
  Activity,
  Anchor,
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  Bell,
  ChevronDown,
  ChevronRight,
  Clock3,
  Compass,
  Database,
  ExternalLink,
  FileText,
  Globe2,
  Layers3,
  LocateFixed,
  Maximize2,
  Minus,
  Navigation,
  Newspaper,
  Pause,
  Play,
  Plus,
  Radio,
  RefreshCw,
  Route as RouteIcon,
  Search,
  Settings2,
  Shield,
  ShieldAlert,
  Ship as ShipIcon,
  Waves,
  X,
} from "lucide-react";
import WorldMap, { type MapActions } from "./components/WorldMap";
import {
  RiskPanel,
  NewsDrawer,
  AnalysisModal,
  DataModal,
} from "./components/Panels";
import type { Snapshot, Position } from "./types";
import { apiFetch, webSocketUrl } from "./lib/api";

const fmt = (v: number) => new Intl.NumberFormat("zh-CN").format(v || 0);
const riskName = (v: number) =>
  v >= 65 ? "高风险" : v >= 45 ? "需关注" : "较平稳";
const riskClass = (v: number) =>
  v >= 65 ? "red" : v >= 45 ? "amber" : "green";
const vesselTypeNames: Record<string, string> = {
  container: "集装箱船",
  tanker: "油轮",
  bulk: "散货船",
  cargo: "货船",
  unknown: "类型待更新",
};
const portStatusNames: Record<string, string> = {
  normal: "示例正常",
  busy: "示例繁忙",
  watch: "示例关注",
};
const dateTime = (d: string | Date | null) =>
  !d
    ? "示例 · 无报道时间"
    : new Date(d).toLocaleString("zh-CN", {
        hour12: false,
        timeZone: "Asia/Shanghai",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });

function App() {
  const [data, setData] = useState<Snapshot | null>(null);
  const [error, setError] = useState("");
  const [connected, setConnected] = useState(false);
  const [clock, setClock] = useState(new Date());
  const [modal, setModal] = useState<"news" | "analysis" | "data" | null>(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [selected, setSelected] = useState<{ kind: string; id: string } | null>(
    null,
  );
  const [layers, setLayers] = useState({
    ships: true,
    routes: true,
    ports: true,
    risk: true,
    news: true,
  });
  const [layersOpen, setLayersOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [riskOnly, setRiskOnly] = useState(false);
  const [paused, setPaused] = useState(false);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [history, setHistory] = useState<Snapshot[]>([]);
  const [mapReady, setMapReady] = useState(false);
  const [notice, setNotice] = useState("");
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const latest = useRef<Snapshot | null>(null);
  const map = useRef<MapActions>(null);
  const mapCard = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let disposed = false;
    let socket: WebSocket | undefined;
    let retry: ReturnType<typeof setTimeout>;
    let fetchBusy = false;
    let lastReceivedAt = 0;
    let requestController: AbortController | undefined;
    let pollingOnly = false;
    const accept = (s: Snapshot) => {
      if (disposed || !s?.ships || !s?.regions) return;
      if (latest.current && Date.parse(s.generatedAt) < Date.parse(latest.current.generatedAt)) return;
      lastReceivedAt = Date.now();
      if (s.status?.transport === "poll") setConnected(true);
      latest.current = s;
      setError("");
      setHistory((h) => [...h.slice(-119), s]);
      if (!pausedRef.current) setData(s);
    };
    const fetchData = () => {
      if (fetchBusy || (socket?.readyState === WebSocket.OPEN && Date.now()-lastReceivedAt < 20000)) return;
      fetchBusy = true;
      requestController = new AbortController();
      const timeout = setTimeout(() => requestController?.abort(), 20000);
      return apiFetch("/api/snapshot", { signal: requestController.signal })
        .then((r) => {
          if (!r.ok) throw new Error(`服务返回 ${r.status}`);
          return r.json();
        })
        .then(accept)
        .catch((e) => {
          if (!disposed && !latest.current)
            setError(`态势服务连接失败：${e.message}。请检查网络和平台是否已启动。`);
        })
        .finally(() => { fetchBusy = false; clearTimeout(timeout); });
    };
    fetchData();
    const connect = () => {
      if (pollingOnly || disposed) return;
      socket = new WebSocket(
        webSocketUrl(),
      );
      socket.onopen = () => {
        if (!disposed) setConnected(true);
      };
      socket.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data);
          accept(msg.data || msg.snapshot || msg);
        } catch {}
      };
      socket.onclose = () => {
        if (!disposed) {
          setConnected(false);
          retry = setTimeout(connect, 5000);
        }
      };
      socket.onerror = () => socket?.close();
    };
    void apiFetch("/api/runtime")
      .then(response => { if (!response.ok) throw new Error("runtime unavailable"); return response.json(); })
      .then(config => { pollingOnly = config.transport === "poll"; if (!pollingOnly) connect(); })
      .catch(() => connect());
    const poll = setInterval(fetchData, 10000);
    const tick = setInterval(() => setClock(new Date()), 1000);
    return () => {
      disposed = true;
      clearTimeout(retry);
      clearInterval(poll);
      clearInterval(tick);
      requestController?.abort();
      socket?.close();
    };
  }, []);
  useEffect(() => {
    if (!paused && latest.current) setData(latest.current);
  }, [paused]);
  useEffect(() => {
    if (notice) {
      const t = setTimeout(() => setNotice(""), 4200);
      return () => clearTimeout(t);
    }
  }, [notice]);

  const select = (kind: string, id: string) => {
    setSelected({ kind, id });
    const list: any[] =
      kind === "ship"
        ? data?.ships || []
        : kind === "region"
          ? data?.regions || []
          : kind === "port"
            ? data?.ports || []
            : data?.routes || [];
    const obj = list.find((v) => v.id === id);
    const pos =
      obj?.position ||
      obj?.coordinates?.[Math.floor(obj.coordinates.length / 2)];
    if (pos)
      map.current?.flyTo(
        pos,
        kind === "ship" || kind === "port" ? 5 : kind === "route" ? 2.5 : 4,
      );
    setQuery("");
    setSearchOpen(false);
  };
  const refresh = async () => {
    try {
      const r = await apiFetch("/api/refresh", { method: "POST" });
      if (!r.ok) throw new Error("刷新暂不可用");
      const n = await apiFetch("/api/snapshot").then((r) => r.json());
      latest.current = n;
      if (!paused) setData(n);
      setNotice("已请求刷新，新闻采集状态可在数据接入中查看");
    } catch (e: any) {
      setNotice(e.message);
    }
  };
  const syncSnapshot = async () => {
    const response = await apiFetch("/api/snapshot");
    if (!response.ok) throw new Error("态势同步失败");
    const next = await response.json();
    latest.current = next;
    if (!pausedRef.current) setData(next);
  };
  const openAnalysis = async () => {
    try {
      if (document.fullscreenElement) {
        if (typeof document.exitFullscreen !== "function") {
          setNotice("请先退出地图全屏，再打开航线研判");
          return;
        }
        await document.exitFullscreen();
      }
      setModal("analysis");
    } catch {
      setNotice("请先退出地图全屏，再打开航线研判");
    }
  };
  const toggleMapFullscreen = async () => {
    try {
      if (
        document.fullscreenElement &&
        typeof document.exitFullscreen === "function"
      ) {
        await document.exitFullscreen();
      } else if (typeof mapCard.current?.requestFullscreen === "function") {
        await mapCard.current.requestFullscreen();
      } else {
        setNotice("当前浏览器不支持全屏，请使用地图缩放查看");
      }
    } catch {
      setNotice("无法切换全屏，请使用地图缩放查看");
    }
  };
  const exportData = () => {
    if (!data) return;
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `观澜航运态势_${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setNotice("态势快照已导出，包含数据来源与时间戳");
  };
  const goTab = (tab: string) => {
    setActiveTab(tab);
    if (tab === "news") setModal("news");
    else if (tab === "analysis") void openAnalysis();
    else if (tab === "routes") {
      setRiskOnly(false);
      document
        .querySelector(".route-table")
        ?.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  };
  const suggestions = useMemo(() => {
    if (!data || !query.trim()) return [];
    const q = query.toLowerCase();
    return [
      ...data.ports.map((p) => ({ ...p, kind: "port", label: "港口" })),
      ...data.regions.map((r) => ({ ...r, kind: "region", label: "风险区域" })),
      ...data.ships.map((s) => ({ ...s, kind: "ship", label: "船舶" })),
      ...data.routes.map((r) => ({ ...r, kind: "route", label: "航道" })),
    ]
      .filter((v: any) =>
        `${v.name} ${v.enName || ""} ${v.mmsi || ""}`.toLowerCase().includes(q),
      )
      .slice(0, 7);
  }, [data, query]);
  const highRisk = data?.regions.filter((r) => r.riskScore >= 65).length || 0;
  const realNews = data?.news.filter((n) => !n.isDemo).length || 0;
  const currentRisk = data
    ? Math.round(
        data.regions.reduce((s, r) => s + r.riskScore, 0) /
          Math.max(data.regions.length, 1),
      )
    : 0;
  const selectedItem: any = !selected
    ? null
    : (selected.kind === "ship"
        ? data?.ships
        : selected.kind === "port"
          ? data?.ports
          : selected.kind === "region"
            ? data?.regions
            : data?.routes
      )?.find((v) => v.id === selected.id);
  const monitoredRoutes =
    data?.routes
      .filter((r) => !riskOnly || r.riskScore >= 45)
      .slice(0, activeTab === "routes" ? undefined : 4) || [];
  const aisStale =
    data?.mode === "live" &&
    ["stale", "error", "connecting"].includes(data?.status?.ais?.state);
  const aisSourceLabel = !data
    ? "等待数据"
    : data.mode !== "live"
      ? "模拟船位"
      : aisStale
        ? "船位延迟"
        : "真实接收";
  const newsState = data?.status?.news?.state;
  const newsSourceLabel = !data
    ? "等待数据"
    : newsState === "live"
      ? "真实报道 · 10分钟采样"
      : newsState === "loading"
        ? "更新中 · 10分钟采样"
        : newsState === "stale"
          ? "采集异常 · 保留上次"
          : newsState === "error"
            ? "采集异常 · 演示情景"
            : "待采集 · 演示情景";
  const modalData = data || { ports: [], regions: [], news: [], status: {} };

  return (
    <div className="app-shell">
      <aside className="rail">
        <button
          className="brand-mark"
          onClick={() => {
            map.current?.reset();
            goTab("overview");
          }}
          aria-label="观澜首页"
        >
          <Navigation size={25} fill="currentColor" />
        </button>
        <div className="rail-links">
          {[
            { id: "overview", icon: Globe2, title: "全球态势" },
            { id: "routes", icon: RouteIcon, title: "航道监测" },
            { id: "news", icon: Newspaper, title: "情报中心" },
            { id: "analysis", icon: Compass, title: "决策分析" },
          ].map((item) => (
            <button
              key={item.id}
              title={item.title}
              aria-label={item.title}
              className={activeTab === item.id ? "active" : ""}
              onClick={() => goTab(item.id)}
            >
              <item.icon size={21} />
            </button>
          ))}
          <span className="rail-divider" />
          <button
            title="地图图层"
            aria-label="地图图层"
            className={layersOpen ? "active" : ""}
            onClick={() => setLayersOpen(!layersOpen)}
          >
            <Layers3 size={21} />
          </button>
          <button
            title="数据接入"
            aria-label="数据接入"
            onClick={() => setModal("data")}
          >
            <Database size={20} />
          </button>
        </div>
        <div className="rail-bottom">
          <button
            title="数据与系统设置"
            aria-label="数据与系统设置"
            onClick={() => setModal("data")}
          >
            <Settings2 size={20} />
          </button>
          <span className="avatar">GL</span>
        </div>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <div className="wordmark">
            <strong>观澜</strong>
            <span>MARITIME SENTINEL</span>
            <span className="workspace-tag">航运安全指挥中心</span>
          </div>
          <nav className="top-nav" aria-label="主导航">
            {[
              ["overview", "全球态势"],
              ["routes", "航道监测"],
              ["news", "情报中心"],
              ["analysis", "决策分析"],
            ].map(([id, title]) => (
              <button
                key={id}
                className={activeTab === id ? "active" : ""}
                onClick={() => goTab(id)}
              >
                {title}
                {id === "news" && realNews > 0 && <span>{realNews}</span>}
              </button>
            ))}
          </nav>
          <div className="top-actions">
            <button
              className="connection-chip"
              onClick={() => setModal("data")}
            >
              <i className={connected ? "status-dot" : "status-dot muted"} />
              {connected ? "态势服务在线" : "正在连接"}
              <ChevronDown size={12} />
            </button>
            <button
              className="icon-button notification"
              title="查看风险预警"
              aria-label="查看风险预警"
              onClick={() => {
                if (data?.regions.length)
                  select(
                    "region",
                    [...data.regions].sort(
                      (a, b) => b.riskScore - a.riskScore,
                    )[0].id,
                  );
              }}
            >
              <Bell size={19} />
              {highRisk > 0 && <i />}
            </button>
          </div>
        </header>

        <main className="main-content">
          <div className="page-heading">
            <div>
              <div className="eyebrow">
                <span />
                GLOBAL MARITIME INTELLIGENCE
              </div>
              <h1>
                全球航运安全态势与决策分析
                <span className="live-pill">
                  <Radio size={12} />
                  {paused
                    ? "快照回看"
                    : data?.mode === "live"
                      ? aisStale
                        ? "船位延迟"
                        : "AIS 接收中"
                      : "船位演示"}
                </span>
              </h1>
              <p>洞察全球航道动态，让每一次航行更有把握。</p>
            </div>
            <div className="heading-actions">
              <div className="clock">
                <Clock3 size={14} />
                <span>{dateTime(clock)}</span>
                <small>UTC+8</small>
              </div>
              <button
                className="button secondary"
                onClick={exportData}
                disabled={!data}
              >
                <ArrowDownToLine size={15} />
                导出态势
              </button>
              <button
                className="button primary"
                onClick={openAnalysis}
              >
                <Compass size={16} />
                智能研判
                <ArrowUpRight size={14} />
              </button>
            </div>
          </div>

          <div className="data-provenance" aria-label="数据来源与更新方式">
            <span
              className={
                data?.mode === "live" && !aisStale ? "is-live" : "is-demo"
              }
              title={
                data?.status?.ais?.message ||
                "未接入有效 AIS 数据时显示合成船位"
              }
            >
              <i
                className={
                  data?.mode === "live" && !aisStale
                    ? "status-dot"
                    : "status-dot muted"
                }
              />
              <strong>AIS：</strong>
              {paused ? `历史快照 · ${aisSourceLabel}` : aisSourceLabel}
            </span>
            <span
              className={newsState === "live" ? "is-live" : "is-demo"}
              title={
                data?.status?.news?.message ||
                "新闻按10分钟间隔采集，不是逐秒更新"
              }
            >
              <i
                className={
                  newsState === "live" ? "status-dot" : "status-dot muted"
                }
              />
              <strong>新闻：</strong>
              {newsSourceLabel}
            </span>
            <span className="is-static">
              <i className="status-dot muted" />
              <strong>港口 / 航道：</strong>静态参考
            </span>
            <span className="is-static">
              <i className="status-dot muted" />
              <strong>风险：</strong>情景规则
            </span>
          </div>

          <div className="metrics-grid">
            <Metric
              icon={<ShipIcon size={20} />}
              title={data?.mode === "live" ? "接收船舶" : "演示船舶"}
              value={data ? fmt(data.ships.length) : "—"}
              unit="艘"
              footer={
                data?.mode === "live"
                  ? data.status?.ais?.publicView ? "外网采样 · 最多400艘" : "授权 AIS 接收范围"
                  : "演示船队 · 轨迹持续推演"
              }
              color="green"
            />
            <Metric
              icon={<RouteIcon size={20} />}
              title="全球重点航道"
              value={data ? fmt(data.routes.length) : "—"}
              unit="条"
              footer={`连接 ${data?.ports.length || "—"} 座主要港口`}
              color="blue"
            />
            <Metric
              icon={<ShieldAlert size={20} />}
              title="高风险关注区域"
              value={data ? String(highRisk).padStart(2, "0") : "—"}
              unit="处"
              footer="历史关注区域 · 规则评估"
              color="amber"
            />
            <Metric
              icon={<Newspaper size={20} />}
              title="24h 新闻采样"
              value={data ? fmt(realNews) : "—"}
              unit="篇"
              footer={
                realNews ? "去重报道 · 按区域归集" : "等待新闻源 · 示例单独标识"
              }
              color="purple"
            />
          </div>

          <div className="dashboard-grid">
            <section className="map-card" ref={mapCard}>
              <div className="section-header map-header">
                <div className="section-title">
                  <Globe2 size={17} />
                  <h2>全球海域态势</h2>
                  <span className="subtle-tag">WGS 84</span>
                </div>
                <div className="map-header-actions">
                  <button
                    className={
                      searchOpen ? "active icon-button" : "icon-button"
                    }
                    onClick={() => setSearchOpen(!searchOpen)}
                    title="搜索船舶、港口与区域"
                    aria-label="搜索船舶、港口与区域"
                  >
                    <Search size={17} />
                  </button>
                  <span className="divider" />
                  <span className="map-scale-text">交互地图 · 拖动 / 缩放</span>
                  <button
                    className="icon-button"
                    onClick={toggleMapFullscreen}
                    title="全屏地图"
                    aria-label="全屏地图"
                  >
                    <Maximize2 size={15} />
                  </button>
                </div>
              </div>
              <div className="map-stage">
                <WorldMap
                  ref={map}
                  data={data}
                  layers={layers}
                  selectedId={selected?.id}
                  onSelect={select}
                  onReady={() => setMapReady(true)}
                />
                {!mapReady && (
                  <div className="map-loading">
                    <Globe2 size={30} />
                    <span>正在建立全球海域视图…</span>
                  </div>
                )}
                <div className="map-context">
                  <span
                    className={`context-state ${data?.mode === "live" ? "" : "demo"}`}
                  >
                    <i className="status-dot" />
                    {data?.mode === "live"
                      ? aisStale
                        ? "AIS 延迟 · 保留船位"
                        : "AIS 实时观测"
                      : "AIS 演示推演"}
                  </span>
                  <span>
                    <Clock3 size={11} />
                    {paused ? "已暂停 · 历史快照" : "持续更新"}
                  </span>
                  <span className="context-note">
                    {data?.mode === "live"
                      ? aisStale
                        ? "连接异常，请留意船位时间"
                        : "接收覆盖由数据源决定"
                      : "接入授权数据后切换实时"}
                  </span>
                </div>
                <span className="ocean-label pacific">
                  P A C I F I C&nbsp; O C E A N
                </span>
                <span className="ocean-label atlantic">A T L A N T I C</span>
                <span className="ocean-label indian">
                  I N D I A N&nbsp; O C E A N
                </span>

                {searchOpen && (
                  <div className="search-panel">
                    <div className="search-field">
                      <Search size={16} />
                      <input
                        autoFocus
                        placeholder="搜索船名 / MMSI / 港口 / 区域"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        aria-label="搜索地图要素"
                      />
                      <button
                        className="icon-button"
                        onClick={() => setSearchOpen(false)}
                        aria-label="关闭搜索"
                      >
                        <X size={15} />
                      </button>
                    </div>
                    {query && (
                      <div className="search-results">
                        {suggestions.length ? (
                          suggestions.map((s: any) => (
                            <button
                              key={`${s.kind}-${s.id}`}
                              onClick={() => select(s.kind, s.id)}
                            >
                              <span>
                                {s.name}
                                <small>{s.mmsi || s.enName}</small>
                              </span>
                              <em>{s.label}</em>
                              <ChevronRight size={13} />
                            </button>
                          ))
                        ) : (
                          <p>未找到匹配对象</p>
                        )}
                      </div>
                    )}
                    <div className="search-hint">
                      快速定位：上海、马六甲、红海，或船舶 MMSI
                    </div>
                  </div>
                )}
                <div className="map-controls">
                  <button
                    aria-label="放大地图"
                    title="放大"
                    onClick={() => map.current?.zoomIn()}
                  >
                    <Plus size={17} />
                  </button>
                  <button
                    aria-label="缩小地图"
                    title="缩小"
                    onClick={() => map.current?.zoomOut()}
                  >
                    <Minus size={17} />
                  </button>
                  <span />
                  <button
                    aria-label="回到全球视图"
                    title="全球视图"
                    onClick={() => {
                      map.current?.reset();
                      setSelected(null);
                    }}
                  >
                    <LocateFixed size={17} />
                  </button>
                  <button
                    aria-label="图层控制"
                    title="图层控制"
                    className={layersOpen ? "active" : ""}
                    onClick={() => setLayersOpen(!layersOpen)}
                  >
                    <Layers3 size={17} />
                  </button>
                </div>
                {layersOpen && (
                  <div className="layers-panel">
                    <div>
                      <strong>地图图层</strong>
                      <button
                        className="icon-button"
                        aria-label="关闭图层"
                        onClick={() => setLayersOpen(false)}
                      >
                        <X size={14} />
                      </button>
                    </div>
                    {[
                      ["ships", "AIS 船舶与轨迹", ShipIcon],
                      ["routes", "全球重要航道", RouteIcon],
                      ["ports", "主要港口", Anchor],
                      ["risk", "历史风险关注区", ShieldAlert],
                      [
                        "news",
                        realNews ? "24h 新闻采样热度" : "示例关注热度",
                        Newspaper,
                      ],
                    ].map(([key, label, Icon]: any) => (
                      <label key={key}>
                        <Icon size={14} />
                        <span>{label}</span>
                        <input
                          type="checkbox"
                          checked={layers[key as keyof typeof layers]}
                          onChange={(e) =>
                            setLayers({ ...layers, [key]: e.target.checked })
                          }
                        />
                        <i className="toggle" />
                      </label>
                    ))}
                  </div>
                )}

                {selectedItem && (
                  <div className="selection-card">
                    <div className="selection-heading">
                      <span>
                        {selected?.kind === "ship"
                          ? "船舶档案"
                          : selected?.kind === "port"
                            ? "港口详情"
                            : selected?.kind === "route"
                              ? "航道详情"
                              : "区域风险档案"}
                      </span>
                      <button
                        className="icon-button"
                        aria-label="关闭详情"
                        onClick={() => setSelected(null)}
                      >
                        <X size={14} />
                      </button>
                    </div>
                    <h3>{selectedItem.name}</h3>
                    {selected?.kind === "ship" ? (
                      <>
                        <p className="mono">MMSI {selectedItem.mmsi}</p>
                        <div className="selection-stats">
                          <span>
                            航速
                            <strong>
                              {selectedItem.speedAvailable === false
                                ? "—"
                                : Number(selectedItem.speed).toFixed(1)}{" "}
                              <small>kn</small>
                            </strong>
                          </span>
                          <span>
                            航向
                            <strong>
                              {selectedItem.courseAvailable === false
                                ? "—"
                                : `${Math.round(selectedItem.course)}°`}
                            </strong>
                          </span>
                          <span>
                            风险
                            <strong
                              className={riskClass(selectedItem.riskScore)}
                            >
                              {selectedItem.riskScore}
                            </strong>
                          </span>
                        </div>
                        <p>
                          {vesselTypeNames[selectedItem.type] ||
                            selectedItem.type}{" "}
                          ·{" "}
                          {!selectedItem.isDemo ? "AISStream 接收" : "演示轨迹"}
                          <br />
                          更新于 {dateTime(selectedItem.updatedAt)}
                        </p>
                      </>
                    ) : selected?.kind === "port" ? (
                      <>
                        <p>
                          {selectedItem.enName} · {selectedItem.country}
                        </p>
                        <div className="selection-stats">
                          <span>
                            坐标
                            <strong className="small-value">
                              {selectedItem.position
                                .map((p: number) => p.toFixed(2))
                                .join(", ")}
                            </strong>
                          </span>
                          <span>
                            状态
                            <strong className="small-value green">
                              {portStatusNames[selectedItem.status] ||
                                selectedItem.status}
                            </strong>
                          </span>
                        </div>
                        <p>港口静态地理资料 · 非实时拥堵监测</p>
                      </>
                    ) : (
                      <>
                        <div className="selection-stats">
                          <span>
                            规则风险指数
                            <strong
                              className={riskClass(selectedItem.riskScore)}
                            >
                              {selectedItem.riskScore}
                              <small> /100</small>
                            </strong>
                          </span>
                          <span>
                            等级
                            <strong
                              className={`small-value ${riskClass(selectedItem.riskScore)}`}
                            >
                              {riskName(selectedItem.riskScore)}
                            </strong>
                          </span>
                        </div>
                        <p>
                          {selected?.kind === "region"
                            ? (selectedItem.factors || [])
                                .map((x: any) =>
                                  typeof x === "string" ? x : x.name || x.label,
                                )
                                .join(" · ")
                            : `关联 ${selectedItem.regionIds?.length || 0} 个关注区域`}
                        </p>
                        <button
                          className="text-link"
                          onClick={openAnalysis}
                        >
                          进入航线研判
                          <ArrowRight size={13} />
                        </button>
                      </>
                    )}
                  </div>
                )}

                <div className="map-legend">
                  <span>
                    <i className="legend-ship" />
                    船舶
                  </span>
                  <span>
                    <i className="legend-port" />
                    港口
                  </span>
                  <span>
                    <i className="legend-route" />
                    航道
                  </span>
                  <span className="legend-divider" />
                  <span>
                    <i className="legend-dot green-bg" />
                    较平稳
                  </span>
                  <span>
                    <i className="legend-dot amber-bg" />
                    需关注
                  </span>
                  <span>
                    <i className="legend-dot red-bg" />
                    高风险
                  </span>
                </div>
                <div className="map-attribution">
                  © Natural Earth · 离线矢量底图
                </div>
              </div>
              <div className="timeline">
                <button
                  className="play-control"
                  onClick={() => {
                    setPaused(!paused);
                    setHistoryIndex(Math.max(0, history.length - 1));
                  }}
                  aria-label={paused ? "恢复最新态势" : "暂停态势"}
                >
                  {paused ? (
                    <Play size={13} fill="currentColor" />
                  ) : (
                    <Pause size={13} fill="currentColor" />
                  )}
                </button>
                <span
                  className={paused ? "timeline-label amber" : "timeline-label"}
                >
                  {paused ? "快照回看" : "跟随最新"}
                </span>
                <div className="timeline-track">
                  <input
                    type="range"
                    min={0}
                    max={Math.max(1, history.length - 1)}
                    value={
                      paused ? historyIndex : Math.max(1, history.length - 1)
                    }
                    onChange={(e) => {
                      const i = Number(e.target.value);
                      if (history[i]) {
                        setHistoryIndex(i);
                        setPaused(true);
                        setData(history[i]);
                      }
                    }}
                    aria-label="回看已接收的态势快照"
                  />
                  <div className="timeline-ticks">
                    {Array.from({ length: 31 }, (_, i) => (
                      <i key={i} />
                    ))}
                  </div>
                </div>
                <span className="timeline-time">
                  {data ? dateTime(data.generatedAt).slice(-8) : "--:--:--"}
                </span>
                <button
                  className="follow-button"
                  onClick={() => {
                    setPaused(false);
                  }}
                >
                  <Radio size={12} />
                  最新
                </button>
              </div>
            </section>

            <aside className="risk-sidebar">
              <RiskPanel
                regions={modalData.regions}
                news={modalData.news}
                onSelectRegion={(region) => select("region", region.id)}
                selectedRegionId={
                  selected?.kind === "region" ? selected.id : undefined
                }
              />
              <div className="intelligence-brief">
                <div className="brief-icon">
                  <Compass size={21} />
                </div>
                <div>
                  <span className="eyebrow">DECISION SUPPORT</span>
                  <h3>从态势感知，到航行决策</h3>
                  <p>
                    结合航道、区域风险与新闻信号，
                    <br />
                    生成可追溯的航线评估。
                  </p>
                  <button onClick={openAnalysis}>
                    开始智能研判
                    <ArrowUpRight size={14} />
                  </button>
                </div>
                <div className="brief-orbit" />
              </div>
            </aside>

            <section
              className={`route-table ${activeTab === "routes" ? "highlight-panel" : ""}`}
            >
              <div className="section-header">
                <div className="section-title">
                  <RouteIcon size={17} />
                  <h2>重点航道运行监测</h2>
                  <span className="count-tag">{data?.routes.length || 0}</span>
                </div>
                <div className="table-tabs">
                  <button
                    className={!riskOnly ? "active" : ""}
                    onClick={() => setRiskOnly(false)}
                  >
                    全部航道
                  </button>
                  <button
                    className={riskOnly ? "active" : ""}
                    onClick={() => setRiskOnly(true)}
                  >
                    风险关注
                    <span>
                      {data?.routes.filter((r) => r.riskScore >= 45).length ||
                        0}
                    </span>
                  </button>
                </div>
              </div>
              <div className="route-table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>航道 / 航线</th>
                      <th>覆盖港口</th>
                      <th>{data?.mode === "live" ? "航道关联" : "示例船数"}</th>
                      <th>规则风险</th>
                      <th>态势等级</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {monitoredRoutes.map((route) => {
                      const count =
                        data?.ships.filter((s) => s.routeId === route.id)
                          .length || 0;
                      const ports =
                        route.portIds
                          ?.map(
                            (id) => data?.ports.find((p) => p.id === id)?.name,
                          )
                          .filter(Boolean) || [];
                      return (
                        <tr
                          key={route.id}
                          onClick={() => select("route", route.id)}
                          tabIndex={0}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") select("route", route.id);
                          }}
                          aria-label={`定位${route.name}`}
                        >
                          <td>
                            <span
                              className={`route-indicator ${riskClass(route.riskScore)}-bg`}
                            />
                            {route.name}
                          </td>
                          <td className="port-cell">
                            {ports.length
                              ? ports.slice(0, 2).join(" → ")
                              : "跨区域航线"}
                          </td>
                          <td className="mono">
                            {data?.mode === "live" ? (
                              <span title="当前 AIS 报文未提供航线归属">—</span>
                            ) : (
                              <>
                                {count}
                                <small> 艘</small>
                              </>
                            )}
                          </td>
                          <td>
                            <div className="risk-meter">
                              <span className={riskClass(route.riskScore)}>
                                {route.riskScore}
                              </span>
                              <i>
                                <b
                                  className={`${riskClass(route.riskScore)}-bg`}
                                  style={{ width: `${route.riskScore}%` }}
                                />
                              </i>
                            </div>
                          </td>
                          <td>
                            <span
                              className={`risk-badge ${riskClass(route.riskScore)}`}
                            >
                              <i />
                              {riskName(route.riskScore)}
                            </span>
                          </td>
                          <td>
                            <ChevronRight size={14} />
                          </td>
                        </tr>
                      );
                    })}
                    {!data && (
                      <tr>
                        <td colSpan={6} className="empty-state">
                          正在接收航道数据…
                        </td>
                      </tr>
                    )}
                    {data && !monitoredRoutes.length && (
                      <tr>
                        <td colSpan={6} className="empty-state">
                          当前筛选范围内暂无风险关注航道
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              <div className="table-footer">
                <span>
                  <Shield size={12} />
                  风险指数为规则评估，航道走向仅供态势展示
                </span>
                <button
                  className="text-link"
                  onClick={() => {
                    goTab(activeTab === "routes" ? "overview" : "routes");
                  }}
                >
                  {activeTab === "routes"
                    ? "收起航道列表"
                    : `查看全部 ${data?.routes.length || 0} 条航道`}
                  <ArrowRight size={12} />
                </button>
              </div>
            </section>
            <section className="news-preview">
              <div className="section-header">
                <div className="section-title">
                  <Activity size={16} />
                  <h2>情报速览</h2>
                </div>
                <button className="text-link" onClick={() => setModal("news")}>
                  全部
                  <ArrowUpRight size={13} />
                </button>
              </div>
              {data?.news?.slice(0, 2).map((n, i) => (
                <button
                  key={n.id}
                  className="news-preview-item"
                  onClick={() => setModal("news")}
                >
                  <span className="news-number">0{i + 1}</span>
                  <div>
                    <span
                      className={`tiny-tag ${n.isDemo ? "amber" : "green"}`}
                    >
                      {n.isDemo ? "演示情景" : "新闻采样"}
                    </span>
                    <h3>{n.title}</h3>
                    <p>
                      {n.source} <span>·</span>{" "}
                      {n.isDemo
                        ? "非真实报道"
                        : dateTime(n.publishedAt).slice(0, -3)}
                    </p>
                  </div>
                  <ArrowUpRight size={14} />
                </button>
              ))}
              {data && !data.news.length && (
                <div className="empty-state">
                  <Newspaper size={24} />
                  <p>正在等待有效新闻采样</p>
                  <button className="text-link" onClick={refresh}>
                    刷新新闻源
                    <RefreshCw size={12} />
                  </button>
                </div>
              )}
            </section>
          </div>
          {error && (
            <div className="error-banner">
              <ShieldAlert size={17} />
              {error}
              <button onClick={() => location.reload()}>重试</button>
            </div>
          )}
          <footer className="app-footer">
            <p className="copyright">©上海交通大学智慧航运与现代物流课题组</p>
            <span>
              <span className="status-dot" />
              观澜 MARITIME SENTINEL <i />
              {data?.mode === "live"
                ? "AIS 授权接入模式"
                : "演示模式 · 非真实船舶位置"}
              <i />
              规则评估仅供辅助研判
            </span>
            <button onClick={() => setModal("data")}>
              数据来源与接入说明
              <ExternalLink size={11} />
            </button>
          </footer>
        </main>
      </div>
      {modal === "news" && (
        <NewsDrawer
          news={modalData.news}
          regions={modalData.regions}
          source={modalData.status?.news?.source}
          onClose={() => setModal(null)}
          onSelectRegion={(region) => {
            select("region", region.id);
            setModal(null);
          }}
        />
      )}
      {modal === "analysis" && (
        <AnalysisModal ports={modalData.ports} onClose={() => setModal(null)} />
      )}
      {modal === "data" && (
        <DataModal
          status={{
            ...modalData.status,
            mode: data?.mode,
            metadata: data?.metadata,
            newsCount: realNews,
          }}
          onClose={() => setModal(null)}
          onRefresh={syncSnapshot}
        />
      )}
      {notice && (
        <div className="toast">
          <Shield size={16} />
          {notice}
          <button aria-label="关闭提示" onClick={() => setNotice("")}>
            <X size={13} />
          </button>
        </div>
      )}
    </div>
  );
}

function Metric({
  icon,
  title,
  value,
  unit,
  footer,
  color,
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
  unit: string;
  footer: string;
  color: string;
}) {
  return (
    <div className={`metric-card ${color}`}>
      <div className="metric-title">
        {title}
        <span>{icon}</span>
      </div>
      <div className="metric-value">
        {value}
        <small>{unit}</small>
      </div>
      <div className="metric-footer">
        <span>
          <i />
          {footer}
        </span>
      </div>
      <div className="metric-art" aria-hidden="true">
        {icon}
      </div>
    </div>
  );
}

export default App;
